﻿using System;
using System.Collections.Generic;
using System.Linq;

public class BankAccount
{
    
    public string AccountID { get; private set;} // Unique identifier for the account
    public string AccountHolderName { get; private set; } // Name of the account holder
    public decimal Balance { get; private set; } // Current balance of the account

    // Constructor to initialize a new BankAccount object
    public BankAccount(string accountId, string accountHolderName, decimal initialBalance = 0)
    {
        // Basic validation for inputs
        if (string.IsNullOrWhiteSpace(accountId))
        {
            throw new ArgumentException("Account ID cannot be null or empty.");
        }
        if (string.IsNullOrWhiteSpace(accountHolderName))
        {
            throw new ArgumentException("Account holder name cannot be null or empty.");
        }
        if (initialBalance < 0)
        {
            throw new ArgumentException("Initial balance cannot be negative.");
        }

        AccountID = accountId;
        AccountHolderName = accountHolderName;
        Balance = initialBalance;
        Console.WriteLine($"\nAccount created for {AccountHolderName} (ID: {AccountID}) with initial balance: {Balance:C}");
    }

    // Method to deposit money into the account
    public bool Deposit(decimal amount)
    {
        if (amount <= 0)
        {
            Console.WriteLine("Deposit amount must be positive.");
            return false;
        }

        Balance += amount;
        Console.WriteLine($"Successfully deposited {amount:C} into account {AccountID}. New balance: {Balance:C}");
        return true;
    }

    // Method to withdraw money from the account
    public bool Withdraw(decimal amount)
    {
        if (amount <= 0)
        {
            Console.WriteLine("Withdrawal amount must be positive.");
            return false;
        }

        // Edge case: Check if there are sufficient funds
        if (amount > Balance)
        {
            Console.WriteLine($"Insufficient funds! Current balance: {Balance:C}. You tried to withdraw: {amount:C}");
            return false;
        }

        Balance -= amount;
        Console.WriteLine($"Successfully withdrew {amount:C} from account {AccountID}. New balance: {Balance:C}");
        return true;
    }

    // Method to view the current balance
    public void ViewBalance()
    {
        Console.WriteLine($"\nAccount ID: {AccountID}");
        Console.WriteLine($"Account Holder: {AccountHolderName}");
        Console.WriteLine($"Current Balance: {Balance:C}");
    }

    // Override ToString for easier display of account info
    public override string ToString()
    {
        return $"ID: {AccountID} | Name: {AccountHolderName} | Balance: {Balance:C}";
    }
}

public class BankSimulator
{
    private static List<BankAccount> accounts = new List<BankAccount>();
    private static BankAccount selectedAccount = null; // To hold the currently selected account

    public static void Main(string[] args)
    {
        // --- Initialize some sample accounts ---
        accounts.Add(new BankAccount("ACC001", "Alice Smith", 500.00m));
        accounts.Add(new BankAccount("ACC002", "Bob Johnson", 1250.75m));
        accounts.Add(new BankAccount("ACC003", "Charlie Brown", 50.25m));

        Console.WriteLine("\n--- Welcome to the Bank Account Simulator ---");

        bool running = true;
        while (running)
        {
            Console.WriteLine("\n--- Main Menu ---");
            if (selectedAccount != null)
            {
                Console.WriteLine($"Currently selected account: {selectedAccount.AccountID} ({selectedAccount.AccountHolderName})");
            }
            else
            {
                Console.WriteLine("No account selected.");
            }

            Console.WriteLine("1. Select Account");
            Console.WriteLine("2. Deposit Funds");
            Console.WriteLine("3. Withdraw Funds");
            Console.WriteLine("4. View Balance");
            Console.WriteLine("5. List All Accounts");
            Console.WriteLine("6. Exit");
            Console.Write("Enter your choice: ");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    SelectAccount();
                    break;
                case "2":
                    PerformDeposit();
                    break;
                case "3":
                    PerformWithdrawal();
                    break;
                case "4":
                    PerformViewBalance();
                    break;
                case "5":
                    ListAllAccounts();
                    break;
                case "6":
                    running = false;
                    Console.WriteLine("Thank you for using the Bank Account Simulator. Goodbye!");
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
            Console.Clear(); // Clears the console for a cleaner look each iteration
        }
    }

    private static void SelectAccount()
    {
        Console.Write("Enter the Account ID to select: ");
        string accountId = Console.ReadLine().Trim();

        // Use LINQ's FirstOrDefault to find the account easily
        selectedAccount = accounts.FirstOrDefault(acc => acc.AccountID.Equals(accountId, StringComparison.OrdinalIgnoreCase));

        if (selectedAccount != null)
        {
            Console.WriteLine($"Account {selectedAccount.AccountID} ({selectedAccount.AccountHolderName}) selected successfully!");
        }
        else
        {
            Console.WriteLine($"Account with ID '{accountId}' not found.");
        }
    }

    private static void PerformDeposit()
    {
        if (!IsAccountSelected()) return;

        Console.Write("Enter amount to deposit: ");
        if (decimal.TryParse(Console.ReadLine(), out decimal amount))
        {
            selectedAccount.Deposit(amount);
        }
        else
        {
            Console.WriteLine("Invalid amount. Please enter a numeric value.");
        }
    }

    private static void PerformWithdrawal()
    {
        if (!IsAccountSelected()) return;

        Console.Write("Enter amount to withdraw: ");
        if (decimal.TryParse(Console.ReadLine(), out decimal amount))
        {
            selectedAccount.Withdraw(amount);
        }
        else
        {
            Console.WriteLine("Invalid amount. Please enter a numeric value.");
        }
    }

    private static void PerformViewBalance()
    {
        if (!IsAccountSelected()) return;
        selectedAccount.ViewBalance();
    }

    private static void ListAllAccounts()
    {
        if (accounts.Count == 0)
        {
            Console.WriteLine("No accounts currently registered.");
            return;
        }

        Console.WriteLine("\n--- All Bank Accounts ---");
        foreach (var account in accounts)
        {
            Console.WriteLine(account); // Uses the overridden ToString() method
        }
    }

    // Helper method to check if an account is selected before performing actions
    private static bool IsAccountSelected()
    {
        if (selectedAccount == null)
        {
            Console.WriteLine("Please select an account first (Option 1).");
            return false;
        }
        return true;
    }
}